import React, { useState } from "react";

const vorlagen = {
  "CT Kopf": [
    "Keine akute intrakranielle Blutung",
    "Keine raumfordernde Läsion",
    "Altersentsprechende cerebrale Atrophie"
  ],
  "CT Abdomen": [
    "Keine freie Flüssigkeit",
    "Leber unauffällig",
    "Keine Harnstauung"
  ],
  "MRT Kopf": [
    "Keine Raumforderung",
    "Keine multiple Sklerose Herde",
    "Normale Liquorräume"
  ],
  "MRT Prostata": [
    "Prostata unauffällig",
    "Kein Nachweis von malignen Läsionen",
    "Keine Lymphknotenvergrößerung"
  ],
  "Röntgen Thorax": [
    "Keine pulmonalen Infiltrate",
    "Keine Pleuraergüsse",
    "Herzgröße normal"
  ]
};

function App() {
  const [untersuchung, setUntersuchung] = useState("CT Kopf");
  const [checkedItems, setCheckedItems] = useState({});

  const handleCheckboxChange = (item) => {
    setCheckedItems(prev => ({
      ...prev,
      [item]: !prev[item]
    }));
  };

  const generiereBeurteilung = () => {
    const ausgewaehlte = Object.keys(checkedItems).filter(k => checkedItems[k]);
    if (ausgewaehlte.length === 0) return "Keine Befunde ausgewählt.";
    return "Beurteilung: " + ausgewaehlte.join(", ") + ".";
  };

  return (
    <div style={{maxWidth: 600, margin: "20px auto", fontFamily: "Arial, sans-serif"}}>
      <h1>Radiologie Befund App</h1>

      <label>
        Untersuchung auswählen:{" "}
        <select value={untersuchung} onChange={e => {setUntersuchung(e.target.value); setCheckedItems({});}}>
          {Object.keys(vorlagen).map(v => (
            <option key={v} value={v}>{v}</option>
          ))}
        </select>
      </label>

      <div style={{marginTop: 20}}>
        {vorlagen[untersuchung].map(item => (
          <div key={item}>
            <label>
              <input
                type="checkbox"
                checked={checkedItems[item] || false}
                onChange={() => handleCheckboxChange(item)}
              />{" "}
              {item}
            </label>
          </div>
        ))}
      </div>

      <div style={{marginTop: 30, padding: 10, border: "1px solid #ccc", backgroundColor: "#f9f9f9"}}>
        <strong>Generierte Beurteilung:</strong>
        <p>{generiereBeurteilung()}</p>
      </div>
    </div>
  );
}

export default App;